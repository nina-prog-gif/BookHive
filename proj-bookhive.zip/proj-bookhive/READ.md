## Sobre o Projeto
O BookHive é uma plataforma web para gestão de bibliotecas, desenvolvida em Java com Spring Boot. O sistema automatiza processos de empréstimos, controle de acervo e gestão de usuarios, substituindo sistemas manuais e planilhas.


## Funcionalidades Principais
📖 Gestão de Livros - CRUD do catálogo bibliográfico
👥 Gestão de Membros - Cadastro e controle de usuários da biblioteca
🔄 Controle de Empréstimos - Empréstimo, devolução e cálculo de multas
🔐 Sistema de Autenticação - Controle de acesso com dois níveis de permissão
📊 Dashboard Interativo - Métricas e relatórios em tempo real
🎨 Interface Responsiva - Design moderno


## Quick Start

Pré-requisitos
Java 11 ou superior
MySQL 8.0 ou superior
Maven 3.6 ou superior
Git para versionamento
# Instalação 
# 1. Clonar o repositório
git clone https://github.com/seu-usuario/bookhive.git
cd bookhive

# 2. Configurar o banco de dados
mysql -u root -p -e "CREATE DATABASE bookhive_db;"

# 3. Configurar a aplicação (editar arquivo)
cp src/main/resources/application.properties.example src/main/resources/application.properties
# Editar application.properties com suas credenciais MySQL

# 4. Executar a aplicação
mvn spring-boot:run
Acesse: http://localhost:8080
Login de teste: admin@bookhive.com / admin123


## Arquitetura do Sistema
Backend	- Spring Boot 2.7.18, Java 11, Spring Security, JPA/Hibernate
Frontend - Thymeleaf, Bootstrap 5.3, CSS3 Custom, JavaScript ES6+
Database - MySQL 8.0, Spring Data JPA
Ferramentas - Maven, Git, Spring Boot DevTools


## Estrutura do Projeto
src/main/java/com/bookhive/
├── config/
│   ├── SecurityConfig.java                 # Configuração de segurança
│   └── WebConfig.java                     # Configurações web
├── controller/
│   ├── DashboardController.java           # Controller principal
│   ├── LivroController.java               # Gestão de livros
│   ├── MembroController.java              # Gestão de membros
│   ├── EmprestimoController.java          # Controle de empréstimos
│   └── AuthController.java                # Autenticação
├── model/
│   ├── Livro.java                         # Entidade Livro
│   ├── Membro.java                        # Entidade Membro
│   ├── Emprestimo.java                    # Entidade Empréstimo
│   └── Usuario.java                       # Entidade Usuário
├── repository/
│   ├── LivroRepository.java               # Repository Livros
│   ├── MembroRepository.java              # Repository Membros
│   ├── EmprestimoRepository.java          # Repository Empréstimos
│   └── UsuarioRepository.java             # Repository Usuários
├── service/
│   ├── LivroService.java                  # Serviço Livros
│   ├── MembroService.java                 # Serviço Membros
│   ├── EmprestimoService.java             # Serviço Empréstimos
│   └── CustomUserDetailsService.java      # Serviço Autenticação
└── BookhiveApplication.java               # Classe principal



## Modelo de Dados
Diagrama Entidade-Relacionamento

-- Tabela: livros
CREATE TABLE livros (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    titulo VARCHAR(255) NOT NULL,
    autor VARCHAR(255) NOT NULL,
    isbn VARCHAR(20) UNIQUE,
    genero VARCHAR(100),
    ano_publicacao INT,
    quantidade_disponivel INT DEFAULT 0,
    data_criacao TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Tabela: membros  
CREATE TABLE membros (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR(255) NOT NULL,
    email VARCHAR(255) UNIQUE NOT NULL,
    telefone VARCHAR(20),
    data_registro DATE,
    ativo BOOLEAN DEFAULT TRUE,
    data_criacao TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Tabela: emprestimos
CREATE TABLE emprestimos (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    membro_id BIGINT NOT NULL,
    livro_id BIGINT NOT NULL,
    data_emprestimo DATE NOT NULL,
    data_vencimento DATE NOT NULL,
    data_devolucao DATE,
    multa_atraso DECIMAL(10,2) DEFAULT 0.00,
    status ENUM('ATIVO', 'DEVOLVIDO', 'ATRASADO') DEFAULT 'ATIVO',
    FOREIGN KEY (membro_id) REFERENCES membros(id),
    FOREIGN KEY (livro_id) REFERENCES livros(id)
);


## Configuração
application.properties
# Database Configuration
spring.datasource.url=jdbc:mysql://localhost:3306/bookhive_db?useSSL=false&serverTimezone=UTC
spring.datasource.username=seu_usuario
spring.datasource.password=sua_senha

# JPA Configuration
spring.jpa.hibernate.ddl-auto=update
spring.jpa.show-sql=true
spring.jpa.properties.hibernate.dialect=org.hibernate.dialect.MySQL8Dialect

# Security Configuration
spring.security.user.name=admin@bookhive.com
spring.security.user.password=admin123
spring.security.user.roles=BIBLIOTECARIO

# Server Configuration
server.port=8080
server.servlet.session.timeout=1800

# Thymeleaf Configuration
spring.thymeleaf.prefix=classpath:/templates/
spring.thymeleaf.suffix=.html
spring.thymeleaf.cache=false

## Fluxo de Segurança
Login -> Autenticação via Spring Security

Autorização -> Controle baseado em papéis

Sessão -> Timeout de 30 minutos

Logout -> Limpeza de sessão e cookies


## Interface do Usuário
Telas Principais
📊 Dashboard - Visão geral com métricas e gráficos
📚 Livros - Listagem, cadastro e edição do acervo
👥 Membros - Gestão de usuários da biblioteca
🔄 Empréstimos - Controle de empréstimos e devoluções
🔐 Login - Tela de autenticação segura


## Desenvolvimento
Configuração do Ambiente
# 1. Clonar e importar no IDE
git clone [url]

# Importar como projeto Maven na IDE

# 2. Configurar database
mysql -u root -p < docs/database/schema.sql

# 3. Executar em desenvolvimento
mvn spring-boot:run

# 4. Acessar
http://localhost:8080


## Comandos Úteis
# Compilar projeto
mvn clean compile

# Executar testes
mvn test

# Gerar JAR
mvn clean package

# Executar com profile específico
mvn spring-boot:run -Dspring-boot.run.profiles=dev


## Padrões de Código
/**
 * Exemplo de service seguindo padrões do projeto
 */
@Service
@Transactional
public class LivroService {
    
    /**
     * Busca livro por ID com tratamento de erro
     */
    public Livro buscarPorId(Long id) {
        return livroRepository.findById(id)
            .orElseThrow(() -> new EntidadeNaoEncontradaException("Livro não encontrado"));
    }
}


## Funcionalidades Detalhadas
# Gestão de Livros
✅ Cadastro com ISBN, autor, gênero, ano
✅ Controle de quantidade disponível
✅ Busca por título, autor ou ISBN
✅ Edição e exclusão segura

# Gestão de Membros
✅ Cadastro com dados completos
✅ Controle de status (ativo/inativo)
✅ Validação de e-mail único
✅ Exclusão lógica

# Controle de Empréstimos
✅ Realização com validações
✅ Cálculo automático de data de devolução
✅ Controle de multas por atraso
✅ Histórico completo


## Deploy
# 1. Gerar JAR
mvn clean package -DskipTests

# 2. Configurar environment variables
export DB_URL=jdbc:mysql://servidor:3306/bookhive_prod
export DB_USERNAME=usuario_prod
export DB_PASSWORD=senha_segura

# 3. Executar
java -jar target/bookhive-1.0.0.jar

## Script de Deploy
#!/bin/bash
# deploy.sh

echo "🚀 Iniciando deploy..."
sudo systemctl stop bookhive
mvn clean package -DskipTests
sudo systemctl start bookhive
echo "✅ Deploy concluído!"


## Testes
# Estrutura de Testes
src/test/java/com/bookhive/
├── service/
│   ├── LivroServiceTest.java
│   └── EmprestimoServiceTest.java
├── controller/
│   └── LivroControllerTest.java
└── repository/
    └── LivroRepositoryTest.java


## Métricas e Monitoramento
# Endpoints
GET /actuator/health     # Saúde da aplicação
GET /actuator/info       # Informações da aplicação
GET /actuator/metrics    # Métricas detalhadas

# Logs
# Verificar logs da aplicação
tail -f logs/bookhive.log

# Logs típicos
# - Aplicação iniciada na porta 8080
# - Conexão com database estabelecida
# - Tabelas criadas/atualizadas
# - Security configurado

## Contribuição
# Padrões de Commit
git commit -m "feat: adiciona gestão de membros"
git commit -m "fix: corrige cálculo de multas" 
git commit -m "docs: atualiza documentação"


## Licença
Esse projeto foi desenvolvido para fins acadêmicos como parte do curso de Análise e Desenvolvimento de Sistemas, na matéria Linguagem de Programação Orientada à Objetos I.