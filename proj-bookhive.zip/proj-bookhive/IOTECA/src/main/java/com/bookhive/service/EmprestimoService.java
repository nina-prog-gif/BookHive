package com.bookhive.service;

import com.bookhive.model.Emprestimo;
import com.bookhive.model.Livro;
import com.bookhive.repository.EmprestimoRepository;
import org.springframework.stereotype.Service;
import java.time.LocalDate;
import java.util.List;

@Service
public class EmprestimoService {

    private final EmprestimoRepository emprestimoRepository;
    private final LivroService livroService;
    private final MembroService membroService;

    public EmprestimoService(
            EmprestimoRepository emprestimoRepository,
            LivroService livroService,
            MembroService membroService
    ) {
        this.emprestimoRepository = emprestimoRepository;
        this.livroService = livroService;
        this.membroService = membroService;
    }

    public List<emprestimo> listarTodos() {
        return emprestimoRepository.findAll();
    }

    public List<emprestimo> listarAtivos() {
        return emprestimoRepository.findByStatus("ATIVO");
    }

    public emprestimo salvar(emprestimo emprestimo) {

        // Define data de empréstimo automaticamente se não vier
        if (emprestimo.getDataEmprestimo() == null) {
            emprestimo.setDataEmprestimo(LocalDate.now());
        }

        // Define data de vencimento automática (7 dias, por exemplo)
        if (emprestimo.getDataVencimento() == null) {
            emprestimo.setDataVencimento(LocalDate.now().plusDays(7));
        }

        // Marca status como ATIVO se não vier preenchido
        if (emprestimo.getStatus() == null) {
            emprestimo.setStatus("ATIVO");
        }

        // Atualiza quantidade de livros
        Livro livro = emprestimo.getLivro();
        if (livro.getQuantidadeDisponivel() > 0) {
            livro.setQuantidadeDisponivel(livro.getQuantidadeDisponivel() - 1);
            livroService.salvar(livro);
        } else {
            throw new RuntimeException("Livro indisponível para empréstimo");
        }

        return emprestimoRepository.save(emprestimo);
    }

    public long contarEmprestimosAtivos() {
        return emprestimoRepository.findByStatus("ATIVO").size();
    }

    public long contarEmprestimosAtrasados() {
        return emprestimoRepository.findByStatus("ATIVO")
                .stream()
                .filter(e -> e.getDataVencimento() != null
                          && e.getDataVencimento().isBefore(LocalDate.now()))
                .count();
    }

    public List<emprestimo> listarEmprestimosRecentes() {
        List<emprestimo> todos = emprestimoRepository.findAll();
        todos.sort((a, b) -> b.getDataEmprestimo().compareTo(a.getDataEmprestimo()));
        return todos.subList(0, Math.min(5, todos.size()));
    }
}
