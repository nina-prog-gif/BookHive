package com.bookhive.service;

import com.bookhive.model.Usuario;
import com.bookhive.repository.UsuarioRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Optional;

/**
 * Serviço para operações de negócio relacionadas a Usuários.
 */
@Service
public class UsuarioService {

    private final UsuarioRepository usuarioRepository;

    // ✔ Injeção via construtor (recomendada no Spring Boot 2.7 + Hibernate 5.6)
    public UsuarioService(UsuarioRepository usuarioRepository) {
        this.usuarioRepository = usuarioRepository;
    }

    /**
     * Salva ou atualiza um usuário.
     *
     * @param usuario Usuário a ser salvo
     * @return Usuário salvo
     */
    @Transactional
    public Usuario salvar(Usuario usuario) {
        return usuarioRepository.save(usuario);
    }

    /**
     * Busca um usuário pelo ID.
     *
     * @param id ID do usuário
     * @return Usuário encontrado
     * @throws RuntimeException se o usuário não for encontrado
     */
    public Usuario buscarPorId(Long id) {
        return usuarioRepository.findById(id)
                .orElseThrow(() ->
                        new RuntimeException("Usuário não encontrado com ID: " + id));
    }

    /**
     * Busca um usuário pelo email.
     *
     * @param email Email do usuário
     * @return Optional contendo o usuário se encontrado
     */
    public Optional<Usuario> buscarPorEmail(String email) {
        return usuarioRepository.findByEmail(email);
    }

    /**
     * Lista todos os usuários.
     *
     * @return Lista de todos os usuários
     */
    public List<Usuario> listarTodos() {
        return usuarioRepository.findAll();
    }

    /**
     * Exclui um usuário pelo ID.
     *
     * @param id ID do usuário a ser excluído
     */
    @Transactional
    public void excluir(Long id) {
        if (!usuarioRepository.existsById(id)) {
            throw new RuntimeException("Usuário não encontrado com ID: " + id);
        }
        usuarioRepository.deleteById(id);
    }

    /**
     * Verifica se um email já está em uso.
     *
     * @param email Email a ser verificado
     * @return true se o email já estiver em uso
     */
    public boolean emailExiste(String email) {
        return usuario
