package com.bookhive.service;

import com.bookhive.model.Membro;
import com.bookhive.repository.MembroRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
public class MembroService {

    private final MembroRepository membroRepository;

    // ✔ Injeção via construtor: melhor prática
    public MembroService(MembroRepository membroRepository) {
        this.membroRepository = membroRepository;
    }

    // -------- LISTAGENS --------

    public List<Membro> listarTodos() {
        return membroRepository.findAll();
    }

    public List<Membro> listarAtivos() {
        return membroRepository.findByAtivoTrue();
    }

    // -------- CRUD --------

    @Transactional
    public Membro salvar(Membro membro) {
        return membroRepository.save(membro);
    }

    public Membro buscarPorId(Long id) {
        return membroRepository.findById(id)
                .orElseThrow(() -> new RuntimeException(
                        "Membro não encontrado com ID: " + id));
    }

    // Soft delete
    @Transactional
    public void excluir(Long id) {
        Membro membro = buscarPorId(id);
        membro.setAtivo(false);
        membroRepository.save(membro); // atualização em transação
    }

    // -------- MÉTRICAS --------

    public long contarTotalMembros() {
        return membroRepository.count();
    }
}
