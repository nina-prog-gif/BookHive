package com.bookhive.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;

import com.bookhive.model.Livro;
import com.bookhive.service.LivroService;

import org.springframework.validation.BindingResult;
import java.util.List;

@Controller
@RequestMapping("/livros")
public class LivroController {

    private final LivroService livroService;

    public LivroController(LivroService livroService) {
        this.livroService = livroService;
    }

    @GetMapping
    public String listarLivros(Model model) {
        List<Livro> livros = livroService.listarTodos();
        model.addAttribute("livros", livros);
        return "livros/listar";
    }

    @GetMapping("/novo")
    public String mostrarFormularioNovoLivro(Model model) {
        model.addAttribute("livro", new Livro());
        return "livros/formulario";
    }

    @PostMapping("/salvar")
    public String salvarLivro(
            @Valid @ModelAttribute("livro") Livro livro,
            BindingResult result,
            Model model) {

        if (result.hasErrors()) {
            return "livros/formulario";
        }

        livroService.salvar(livro);
        return "redirect:/livros";
    }

    @GetMapping("/excluir/{id}")
    public String excluirLivro(@PathVariable Long id) {

        if (!livroService.existePorId(id)) {
            // Opção 1: logar e ignorar
            // Opção 2: lançar exceção e mostrar tela de erro
            return "redirect:/livros?erro=LivroNaoEncontrado";
        }

        livroService.excluir(id);
        return "redirect:/livros";
    }
}
