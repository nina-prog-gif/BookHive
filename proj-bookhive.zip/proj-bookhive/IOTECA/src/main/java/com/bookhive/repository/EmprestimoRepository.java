package com.bookhive.repository;

import com.bookhive.model.Emprestimo;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.List;

@Repository
public interface EmprestimoRepository extends JpaRepository<Emprestimo, Long> {

    List<Emprestimo> findByStatus(String status);

    List<Emprestimo> findByMembroIdAndStatus(Long membroId, String status);
}
