package com.bookhive.service;

import com.bookhive.model.Livro;
import com.bookhive.repository.LivroRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
public class LivroService {

    private final LivroRepository livroRepository;

    // ✔ Boa prática: Injeção via construtor
    public LivroService(LivroRepository livroRepository) {
        this.livroRepository = livroRepository;
    }

    // -------- LISTAGENS --------

    public List<Livro> listarTodos() {
        return livroRepository.findAll();
    }

    public List<Livro> listarDisponiveis() {
        return livroRepository.findByQuantidadeDisponivelGreaterThan(0);
    }

    // -------- CRUD --------

    @Transactional
    public Livro salvar(Livro livro) {
        return livroRepository.save(livro);
    }

    public Livro buscarPorId(Long id) {
        return livroRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Livro não encontrado com ID: " + id));
    }

    @Transactional
    public void excluir(Long id) {
        livroRepository.deleteById(id);
    }

    // -------- MÉTRICAS --------

    public long contarTotalLivros() {
        return livroRepository.count();
    }
}
