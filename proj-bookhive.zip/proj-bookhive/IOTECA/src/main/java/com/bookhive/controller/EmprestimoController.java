package com.bookhive.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import javax.validation.Valid;

import com.bookhive.model.Emprestimo;
import com.bookhive.service.EmprestimoService;
import com.bookhive.service.LivroService;
import com.bookhive.service.MembroService;

import org.springframework.validation.BindingResult;
import java.util.List;

@Controller
@RequestMapping("/emprestimos")
public class EmprestimoController {

    private final EmprestimoService emprestimoService;
    private final LivroService livroService;
    private final MembroService membroService;

    public EmprestimoController(
            EmprestimoService emprestimoService,
            LivroService livroService,
            MembroService membroService) {
        this.emprestimoService = emprestimoService;
        this.livroService = livroService;
        this.membroService = membroService;
    }

    @GetMapping
    public String listarEmprestimos(Model model) {
        List<Emprestimo> emprestimos = emprestimoService.listarTodosComAssociacoes(); 
        model.addAttribute("emprestimos", emprestimos);
        return "emprestimos/listar";
    }

    @GetMapping("/novo")
    public String mostrarFormularioNovoEmprestimo(Model model) {
        model.addAttribute("emprestimo", new Emprestimo());
        model.addAttribute("livros", livroService.listarDisponiveis());
        model.addAttribute("membros", membroService.listarAtivos());
        return "emprestimos/novo";
    }

    @PostMapping("/salvar")
    public String salvarEmprestimo(
            @Valid @ModelAttribute("emprestimo") Emprestimo emprestimo,
            BindingResult result,
            Model model) {

        if (result.hasErrors()) {
            model.addAttribute("livros", livroService.listarDisponiveis());
            model.addAttribute("membros", membroService.listarAtivos());
            return "emprestimos/novo";
        }

        // Reforço de regras de negócio
        if (!livroService.estaDisponivel(emprestimo.getLivro().getId())) {
            result.rejectValue("livro", null, "Este livro não está disponível.");
            model.addAttribute("livros", livroService.listarDisponiveis());
            model.addAttribute("membros", membroService.listarAtivos());
            return "emprestimos/novo";
        }

        emprestimoService.salvar(emprestimo);
        return "redirect:/emprestimos";
    }
}
