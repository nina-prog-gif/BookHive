package com.bookhive.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import com.bookhive.model.Membro;
import com.bookhive.service.MembroService;

import javax.validation.Valid;
import java.util.List;

@Controller
@RequestMapping("/membros")
public class MembroController {

    private final MembroService membroService;

    public MembroController(MembroService membroService) {
        this.membroService = membroService;
    }

    @GetMapping
    public String listarMembros(Model model) {
        List<Membro> membros = membroService.listarTodos();
        model.addAttribute("membros", membros);
        return "membros/listar";
    }

    @GetMapping("/novo")
    public String mostrarFormularioNovoMembro(Model model) {
        model.addAttribute("membro", new Membro());
        return "membros/formulario";
    }

    @PostMapping("/salvar")
    public String salvarMembro(@Valid @ModelAttribute Membro membro) {
        membroService.salvar(membro);
        return "redirect:/membros";
    }

    @GetMapping("/excluir/{id}")
    public String excluirMembro(@PathVariable Long id) {
        membroService.excluir(id);
        return "redirect:/membros";
    }
}
