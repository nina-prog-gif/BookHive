package com.bookhive.model;

import javax.persistence.*;
import javax.validation.constraints.NotNull;
import java.time.LocalDate;

@Entity
@Table(name = "emprestimos")
public class Emprestimo {
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY) 
    @JoinColumn(name = "membro_id", nullable = false)
    @NotNull(message = "O membro é obrigatório.")
    private Membro membro;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "livro_id", nullable = false)
    @NotNull(message = "O livro é obrigatório.")
    private Livro livro;

    @Column(name = "data_emprestimo", nullable = false)
    @NotNull(message = "A data do empréstimo é obrigatória.")
    private LocalDate dataEmprestimo;

    @Column(name = "data_vencimento", nullable = false)
    @NotNull(message = "A data de vencimento é obrigatória.")
    private LocalDate dataVencimento;

    @Column(name = "data_devolucao")
    private LocalDate dataDevolucao;

    @Column(name = "multa_atraso")
    private Double multaAtraso = 0.0;

    @Column(nullable = false, length = 20)
    private String status;

    public Emprestimo() {}

    public Emprestimo(Membro membro, Livro livro, LocalDate dataEmprestimo, LocalDate dataVencimento) {
        this.membro = membro;
        this.livro = livro;
        this.dataEmprestimo = dataEmprestimo;
        this.dataVencimento = dataVencimento;
    }

    @PrePersist
    public void prePersist() {
        if (status == null) {
            status = "ATIVO";
        }
        if (multaAtraso == null) {
            multaAtraso = 0.0;
        }
    }

    // Getters e Setters
    // ...
}
