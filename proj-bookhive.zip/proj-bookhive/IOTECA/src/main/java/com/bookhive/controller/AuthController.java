package com.bookhive.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

/**
 * Controller para páginas de autenticação e acesso.
 */
@Controller
public class AuthController {

    /**
     * Página de acesso negado.
     */
    @GetMapping("/acesso-negado")
    public String acessoNegado(Model model) {
        model.addAttribute("titulo", "Acesso Negado");
        model.addAttribute("mensagem", "Você não tem permissão para acessar esta página.");
        return "acesso-negado";
    }

    /**
     * Página sobre o sistema.
     */
    @GetMapping("/sobre")
    public String sobre(Model model) {
        model.addAttribute("titulo", "Sobre o BookHive");
        return "sobre";
    }
}