package com.bookhive.model;

import javax.persistence.*;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Size;
import java.util.ArrayList;
import java.util.List;

@Entity
@Table(name = "livros")
public class Livro {
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @NotBlank(message = "O título é obrigatório.")
    @Column(nullable = false, length = 200)
    private String titulo;

    @NotBlank(message = "O autor é obrigatório.")
    @Column(nullable = false, length = 150)
    private String autor;

    @Size(max = 20)
    @Column(length = 20)
    private String isbn;

    @Size(max = 100)
    @Column(length = 100)
    private String genero;

    @Column(name = "ano_publicacao")
    private Integer anoPublicacao;

    @Column(name = "quantidade_disponivel", nullable = false)
    private Integer quantidadeDisponivel = 0;

    @OneToMany(mappedBy = "livro", cascade = CascadeType.ALL, orphanRemoval = false, fetch = FetchType.LAZY)
    private List<Emprestimo> emprestimos = new ArrayList<>();

    // Construtores
    public Livro() {}

    public Livro(String titulo, String autor, String isbn, String genero, Integer anoPublicacao, Integer quantidadeDisponivel) {
        this.titulo = titulo;
        this.autor = autor;
        this.isbn = isbn;
        this.genero = genero;
        this.anoPublicacao = anoPublicacao;
        this.quantidadeDisponivel = quantidadeDisponivel;
    }

    @PrePersist
    public void prePersist() {
        if (quantidadeDisponivel == null)
            quantidadeDisponivel = 0;
    }

    // Getters e Setters

    public boolean isDisponivel() {
        return quantidadeDisponivel != null && quantidadeDisponivel > 0;
    }
}
