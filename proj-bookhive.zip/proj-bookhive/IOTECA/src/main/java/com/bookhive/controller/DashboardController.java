package com.bookhive.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.beans.factory.annotation.Autowired;
import com.bookhive.service.LivroService;
import com.bookhive.service.MembroService;
import com.bookhive.service.EmprestimoService;

@Controller
public class DashboardController {

    @Autowired
    private LivroService livroService;
    
    @Autowired
    private MembroService membroService;
    
    @Autowired
    private EmprestimoService emprestimoService;

    @GetMapping("/login")
    public String login() {
        return "login";
    }

    @GetMapping("/dashboard")
    public String dashboard(Model model) {
        model.addAttribute("totalLivros", livroService.contarTotalLivros());
        model.addAttribute("totalMembros", membroService.contarTotalMembros());
        model.addAttribute("emprestimosAtivos", emprestimoService.contarEmprestimosAtivos());
        model.addAttribute("emprestimosAtrasados", emprestimoService.contarEmprestimosAtrasados());
        return "dashboard";
    }

    @GetMapping("/")
    public String home() {
        return "redirect:/dashboard";
    }
}