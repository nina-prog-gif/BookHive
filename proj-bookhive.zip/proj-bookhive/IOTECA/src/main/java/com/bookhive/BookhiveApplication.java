package com.bookhive;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * Classe principal que inicia a aplicação Spring Boot do sistema BookHive.
 */
@SpringBootApplication
public class BookhiveApplication {

    public static void main(String[] args) {
        SpringApplication.run(BookhiveApplication.class, args);
    }
}
