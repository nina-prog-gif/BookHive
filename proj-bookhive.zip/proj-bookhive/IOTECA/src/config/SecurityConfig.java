package com.bookhive.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.provisioning.InMemoryUserDetailsManager;
import org.springframework.security.web.util.matcher.AntPathRequestMatcher;

import javax.sql.DataSource;

/**
 * Configuração de segurança do Spring Security para o sistema BookHive.
 * Define políticas de acesso, autenticação e autorização.
 * 
 * @author Seu Nome
 * @version 1.0
 */
@Configuration
@EnableWebSecurity
public class SecurityConfig extends WebSecurityConfigurerAdapter {

    private final DataSource dataSource;

    /**
     * Construtor para injeção de dependência do DataSource.
     * 
     * @param dataSource DataSource para conexão com o banco de dados
     */
    public SecurityConfig(DataSource dataSource) {
        this.dataSource = dataSource;
    }

    /**
     * Configura as regras de autorização HTTP e o formulário de login.
     * 
     * @param http Objeto HttpSecurity para configuração
     * @throws Exception Se ocorrer erro na configuração
     */
    @Override
    protected void configure(HttpSecurity http) throws Exception {
        http
            // Configuração de autorização
            .authorizeRequests()
                // Recursos estáticos permitidos para todos
                .antMatchers("/css/**", "/js/**", "/images/**", "/webjars/**").permitAll()
                // Páginas públicas
                .antMatchers("/", "/login", "/sobre", "/contato").permitAll()
                // API REST (se houver) - permitir apenas autenticados
                .antMatchers("/api/**").authenticated()
                // Todas as outras requisições exigem autenticação
                .anyRequest().authenticated()
                .and()
            
            // Configuração do formulário de login
            .formLogin()
                .loginPage("/login")
                .loginProcessingUrl("/login")
                .defaultSuccessUrl("/dashboard", true)
                .failureUrl("/login?error=true")
                .usernameParameter("username")
                .passwordParameter("password")
                .permitAll()
                .and()
            
            // Configuração do logout
            .logout()
                .logoutRequestMatcher(new AntPathRequestMatcher("/logout"))
                .logoutSuccessUrl("/login?logout=true")
                .invalidateHttpSession(true)
                .deleteCookies("JSESSIONID")
                .permitAll()
                .and()
            
            // Configuração de sessão
            .sessionManagement()
                .sessionFixation().migrateSession()
                .maximumSessions(1)
                .expiredUrl("/login?expired=true")
                .and()
                .and()
            
            // Configuração de remember-me
            .rememberMe()
                .key("bookhive-remember-me-key")
                .tokenValiditySeconds(86400) // 24 horas
                .rememberMeParameter("remember-me")
                .and()
            
            // Configuração de exceções
            .exceptionHandling()
                .accessDeniedPage("/acesso-negado")
                .and()
            
            // Configurações de segurança adicionais
            .headers()
                .frameOptions().sameOrigin()
                .httpStrictTransportSecurity().disable()
                .and()
            
            // Configuração CSRF (habilitado por padrão)
            .csrf().disable(); // Em produção, mantenha habilitado e configure corretamente
    }

    /**
     * Configura a autenticação com usuários em memória (para desenvolvimento).
     * Em produção, substituir por autenticação via banco de dados.
     * 
     * @param auth AuthenticationManagerBuilder para configuração
     * @throws Exception caso ocorra erro na configuração
     */
    @Override
    protected void configure(AuthenticationManagerBuilder auth) throws Exception {
        // Para desenvolvimento - usuários em memória
        auth.userDetailsService(userDetailsService()).passwordEncoder(passwordEncoder());
        
    }

    /**
     * Bean para definir os usuários em memória (apenas para desenvolvimento).
     * 
     * @return UserDetailsService com usuários pré-definidos
     */
    @Bean
    @Override
    public UserDetailsService userDetailsService() {
        UserDetails bibliotecario = User.builder()
                .username("admin@bookhive.com")
                .password(passwordEncoder().encode("admin123"))
                .roles("BIBLIOTECARIO")
                .build();

        UserDetails membro = User.builder()
                .username("membro@bookhive.com")
                .password(passwordEncoder().encode("membro123"))
                .roles("MEMBRO")
                .build();

        return new InMemoryUserDetailsManager(bibliotecario, membro);
    }

    /**
     * Bean para encoder de senhas usando BCrypt.
     * 
     * @return PasswordEncoder configurado com BCrypt
     */
    @Bean
    public PasswordEncoder passwordEncoder() {
        return new BCryptPasswordEncoder(12); // Strength 12 para maior segurança
    }

    /**
     * Bean para configuração customizada de CORS (se necessário para APIs).
     * 
     * @return Customizer para CORS
     */
    /*
    @Bean
    public WebMvcConfigurer corsConfigurer() {
        return new WebMvcConfigurer() {
            @Override
            public void addCorsMappings(CorsRegistry registry) {
                registry.addMapping("/api/**")
                        .allowedOrigins("http://localhost:3000")
                        .allowedMethods("GET", "POST", "PUT", "DELETE")
                        .allowedHeaders("*")
                        .allowCredentials(true);
            }
        };
    }
    */
}