package com.bookhive.config;

import org.springframework.security.core.AuthenticationException;
import org.springframework.security.web.authentication.AuthenticationFailureHandler;
import org.springframework.stereotype.Component;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.Date;

/**
 * Handler para tratamento de falhas de login.
 */
@Component
public class CustomAuthenticationFailureHandler implements AuthenticationFailureHandler {

    @Override
    public void onAuthenticationFailure(HttpServletRequest request, 
                                      HttpServletResponse response, 
                                      AuthenticationException exception) throws IOException, ServletException {
        
        // Registrar tentativa falha (em produção, salvar no banco)
        String username = request.getParameter("username");
        String ipAddress = getClientIpAddress(request);
        
        System.out.println("Tentativa de login falhou - Usuário: " + username + 
                          ", IP: " + ipAddress + ", Horário: " + new Date());
        
        // Redirecionar para login com erro
        response.sendRedirect("/login?error=true");
    }
    
    private String getClientIpAddress(HttpServletRequest request) {
        String xfHeader = request.getHeader("X-Forwarded-For");
        if (xfHeader == null) {
            return request.getRemoteAddr();
        }
        return xfHeader.split(",")[0];
    }
}